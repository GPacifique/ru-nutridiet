<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();

            // BASIC INFORMATION
            $table->string('name');
            $table->string('email')->unique();
            $table->string('phone')->nullable();

            // AUTHENTICATION
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');

            // PROFILE
            $table->string('profile_image')->nullable();
            $table->text('bio')->nullable();
            $table->string('address')->nullable();

            // ROLE SYSTEM
            $table->enum('role', [
                'admin',
                'nutritionist',
            ])->default('nutritionist');

            // PROFESSIONAL INFORMATION
            $table->string('professional_registration_number')
                ->nullable()
                ->unique();

            $table->string('license_number')
                ->nullable()
                ->unique();

            $table->string('organization')
                ->nullable();

            $table->string('country')
                ->nullable();

            // ACCOUNT STATUS
            $table->enum('status', [
                'pending',
                'approved',
                'rejected',
                'suspended',
                'inactive',
            ])->default('pending');

            $table->rememberToken();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};